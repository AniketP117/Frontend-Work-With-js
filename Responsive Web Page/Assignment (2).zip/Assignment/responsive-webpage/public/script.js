document.getElementById("collapse-btn").addEventListener("click", () => {
    const leftMenu = document.querySelector(".left-menu");
    leftMenu.style.display = leftMenu.style.display === "none" ? "block" : "";
  });
  
  function adjustWidth() {
    const screenWidth = window.innerWidth;
    const container = document.querySelector(".container");
  
    if (screenWidth <= 600) {
      container.style.transform = "scale(0.5)";
    } else if (screenWidth <= 700) {
      container.style.transform = "scale(0.75)";
    } else if (screenWidth <= 767) {
      container.style.transform = "scale(0.8)";
    } else if (screenWidth <= 1600) {
      container.style.transform = "scale(0.9)";
    } else {
      container.style.transform = "scale(1)";
    }
  }
  
  window.addEventListener("resize", adjustWidth);
  adjustWidth();
  